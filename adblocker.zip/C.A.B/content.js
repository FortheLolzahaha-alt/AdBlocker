// 1. Static CSS hides feed, sidebar, banner, and overlay ads instantly off-thread
const adStyles = document.createElement("style");
adStyles.textContent = `
  ytd-ad-slot-renderer,
  ytd-in-feed-ad-layout-renderer,
  ytd-banner-promo-renderer,
  ytd-statement-banner-renderer,
  #masthead-ad,
  .ytd-merch-shelf-renderer,
  .ytp-ad-overlay-container,
  #player-ads,
  ytd-promoted-sparkles-web-renderer,
  ytd-display-ad-renderer,
  ytd-promoted-video-renderer,
  ytd-compact-promoted-video-renderer,
  yt-mealbar-promo-renderer,
  ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
  ytd-rich-item-renderer:has(.badge-style-type-ad),
  ytd-rich-item-renderer:has([aria-label*="Sponsor"]),
  ytd-rich-item-renderer:has([aria-label*="sponsor"]) {
    display: none !important;
  }
`;
(document.head || document.documentElement).appendChild(adStyles);

// 2. High-speed, microtask-driven video ad engine
function fastSkipAd(player, video) {
  const isAd = player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting");

  if (isAd && video) {
    video.muted = true;
    video.playbackRate = 16;

    // Instantly push to 0.1s before ad completion
    if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.1) {
      video.currentTime = video.duration - 0.1;
    }

    // Click skip button immediately
    const skipBtn = player.querySelector(
      ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-slot, .ytp-ad-skip-button-container button, [class*='skip-button']"
    );
    if (skipBtn) {
      skipBtn.click();
    }
  } else if (video && video.playbackRate > 2) {
    // Instantly restore standard speed & audio for the main video
    video.playbackRate = 1;
    video.muted = false;
  }
}

function initInstantBypass() {
  const player = document.querySelector(".html5-video-player");
  const video = document.querySelector("video");

  if (!player || !video) {
    requestAnimationFrame(initInstantBypass);
    return;
  }

  // Reacts instantly (microsecond level) when YouTube attaches 'ad-showing' to player class
  const playerObserver = new MutationObserver(() => {
    fastSkipAd(player, video);
  });

  playerObserver.observe(player, {
    attributes: true,
    attributeFilter: ["class"]
  });

  // Direct media event hook: fires as soon as an ad frame plays
  video.addEventListener("timeupdate", () => {
    if (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting")) {
      fastSkipAd(player, video);
    }
  });

  fastSkipAd(player, video);
}

// Run immediately
initInstantBypass();