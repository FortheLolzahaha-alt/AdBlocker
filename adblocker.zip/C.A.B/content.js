// 1. Static CSS hides feed, sidebar, banner, and overlay ads instantly off-thread
//    (now also covers Shorts-specific ad slots/badges)
const adStyles = document.createElement("style");
adStyles.textContent = `
  ytd-ad-slot-renderer,
  ytd-in-feed-ad-layout-renderer,
  ytd-banner-promo-renderer,
  ytd-statement-banner-renderer,
  #masthead-ad,
  .ytd-merch-shelf-renderer,
  .ytp-ad-overlay-container,
  #player-ads,
  ytd-promoted-sparkles-web-renderer,
  ytd-display-ad-renderer,
  ytd-promoted-video-renderer,
  ytd-compact-promoted-video-renderer,
  yt-mealbar-promo-renderer,
  ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
  ytd-rich-item-renderer:has(.badge-style-type-ad),
  ytd-rich-item-renderer:has([aria-label*="Sponsor"]),
  ytd-rich-item-renderer:has([aria-label*="sponsor"]),

  /* --- Shorts-specific ad containers/badges --- */
  ytd-reel-video-renderer:has(ytd-ad-slot-renderer),
  ytd-reel-video-renderer:has(.badge-style-type-ad),
  ytd-reel-video-renderer:has([aria-label*="Sponsor"]),
  ytd-reel-shelf-renderer[is-ad-slot],
  ytm-shorts-lockup-view-model:has([aria-label*="Sponsor"]),
  #shorts-player .ytp-ad-overlay-container,
  #shorts-player .ypp-ad-skip-button-container {
    display: none !important;
  }
`;
(document.head || document.documentElement).appendChild(adStyles);

// 2. High-speed, microtask-driven video ad engine
//    Works for both the normal watch-page player and the Shorts player(s).
//    Shorts pre-loads/recycles several <video> elements (prev/current/next
//    reel), so instead of grabbing a single player up front we re-scan
//    for every player/video pair on each tick.
function fastSkipAd(player, video) {
  const isAd = player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting");

  if (isAd && video) {
    video.muted = true;
    video.playbackRate = 16;

    // Instantly push to 0.1s before ad completion
    if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.1) {
      video.currentTime = video.duration - 0.1;
    }

    // Click skip button immediately (covers both watch-page and Shorts skip UI)
    const skipBtn = player.querySelector(
      ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-slot, .ytp-ad-skip-button-container button, [class*='skip-button']"
    );
    if (skipBtn) {
      skipBtn.click();
    }
  } else if (video && video.playbackRate > 2) {
    // Instantly restore standard speed & audio for the main video
    video.playbackRate = 1;
    video.muted = false;
  }
}

// Finds every currently-attached player/video pair on the page.
// On a normal watch page there's one; on /shorts/ there can be several
// (the reel carousel keeps neighboring videos mounted).
function getPlayerVideoPairs() {
  const pairs = [];
  document.querySelectorAll("video").forEach((video) => {
    const player =
      video.closest(".html5-video-player") ||
      video.closest("#shorts-player") ||
      document.querySelector(".html5-video-player");
    if (player) pairs.push({ player, video });
  });
  return pairs;
}

function scanAndSkip() {
  getPlayerVideoPairs().forEach(({ player, video }) => fastSkipAd(player, video));
}

function initInstantBypass() {
  // Reacts instantly when YouTube attaches 'ad-showing' to any player class,
  // and also catches new player nodes being mounted (Shorts swaps these in
  // as the user scrolls between reels).
  const observer = new MutationObserver(scanAndSkip);
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class"],
    subtree: true,
    childList: true,
  });

  // Direct media event hook: fires as soon as any ad frame plays,
  // for either the watch-page video or a Shorts video.
  document.addEventListener(
    "timeupdate",
    (e) => {
      if (e.target && e.target.tagName === "VIDEO") {
        const player =
          e.target.closest(".html5-video-player") || e.target.closest("#shorts-player");
        if (player) fastSkipAd(player, e.target);
      }
    },
    true
  );

  // Safety-net poll: Shorts navigation (swipe) can swap the active video
  // without a class-mutation firing fast enough, so re-check briefly.
  setInterval(scanAndSkip, 250);

  scanAndSkip();
}

// Run immediately
initInstantBypass();