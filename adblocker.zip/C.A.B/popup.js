const toggle = document.getElementById("toggle");
const statusLabel = document.getElementById("statusLabel");
const blockedCountEl = document.getElementById("blockedCount");
const updatesBtn = document.getElementById("updatesBtn");

const UPDATES_URL = "https://github.com/FortheLolzahaha-alt/AdBlocker/blob/main/UPDATES.md";

// --- Helper: animate number count-up ---
let currentDisplayed = 0;

function animateCount(newValue) {
  const target = newValue || 0;
  // Clamp display to 999+
  const displayVal = target > 999 ? "999+" : target;

  if (target > 999) {
    blockedCountEl.textContent = "999+";
    return;
  }

  // If the difference is huge, just jump
  if (Math.abs(target - currentDisplayed) > 100) {
    blockedCountEl.textContent = target;
    currentDisplayed = target;
    return;
  }

  // Smooth step animation
  const start = currentDisplayed;
  const diff = target - start;
  const duration = 200; // ms
  const startTime = performance.now();

  function step(time) {
    const elapsed = time - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(start + diff * eased);
    blockedCountEl.textContent = current;
    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      blockedCountEl.textContent = target;
      currentDisplayed = target;
    }
  }
  requestAnimationFrame(step);
}

function render(enabled, blockedCount) {
  const isEnabled = enabled !== false;
  toggle.checked = isEnabled;

  // Update status text
  if (isEnabled) {
    statusLabel.innerHTML = `<span class="highlight">●</span> Blocking is <strong>on</strong>`;
  } else {
    statusLabel.innerHTML = `<span style="color:#f87171;">●</span> Blocking is <strong>off</strong>`;
  }

  // Update counter with animation
  if (blockedCount !== undefined && blockedCount !== null) {
    animateCount(blockedCount);
  }
}

// --- Load initial state ---
chrome.storage.local.get(["enabled", "blockedCount"], (data) => {
  render(data.enabled, data.blockedCount);
});

// --- Toggle event ---
toggle.addEventListener("change", () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ enabled });
  // Immediately update label (render will be called by storage change, but we do it optimistically)
  if (enabled) {
    statusLabel.innerHTML = `<span class="highlight">●</span> Blocking is <strong>on</strong>`;
  } else {
    statusLabel.innerHTML = `<span style="color:#f87171;">●</span> Blocking is <strong>off</strong>`;
  }
});

// --- Updates button ---
if (updatesBtn) {
  updatesBtn.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: UPDATES_URL });
  });
}

// --- Listen for external storage changes (from background) ---
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.blockedCount) {
      animateCount(changes.blockedCount.newValue || 0);
    }
    if (changes.enabled) {
      const isEnabled = changes.enabled.newValue;
      if (isEnabled) {
        statusLabel.innerHTML = `<span class="highlight">●</span> Blocking is <strong>on</strong>`;
      } else {
        statusLabel.innerHTML = `<span style="color:#f87171;">●</span> Blocking is <strong>off</strong>`;
      }
      toggle.checked = isEnabled;
    }
  }
});