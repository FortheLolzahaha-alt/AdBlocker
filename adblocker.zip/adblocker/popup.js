const toggle = document.getElementById("toggle");
const statusLabel = document.getElementById("statusLabel");
const blockedCountEl = document.getElementById("blockedCount");

function render(enabled, blockedCount) {
  const isEnabled = enabled !== false;
  toggle.checked = isEnabled;
  statusLabel.textContent = isEnabled ? "Blocking is on" : "Blocking is off";
  blockedCountEl.textContent = blockedCount || 0;
}

chrome.storage.local.get(["enabled", "blockedCount"], (data) => {
  render(data.enabled, data.blockedCount);
});

toggle.addEventListener("change", () => {
  const enabled = toggle.checked;
  statusLabel.textContent = enabled ? "Blocking is on" : "Blocking is off";
  chrome.storage.local.set({ enabled });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.blockedCount) {
      blockedCountEl.textContent = changes.blockedCount.newValue || 0;
    }
    if (changes.enabled) {
      render(changes.enabled.newValue, null);
    }
  }
});