const RULESET_ID = "ruleset_1";

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ enabled: true, blockedCount: 0 });
  await updateRuleset(true);
});

async function updateRuleset(shouldEnable) {
  if (shouldEnable) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: [RULESET_ID]
    });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      disableRulesetIds: [RULESET_ID]
    });
  }
}

chrome.runtime.onStartup.addListener(async () => {
  const { enabled = true } = await chrome.storage.local.get("enabled");
  await updateRuleset(enabled);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.enabled) {
    updateRuleset(changes.enabled.newValue);
  }
});

if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(async () => {
    const { blockedCount = 0 } = await chrome.storage.local.get("blockedCount");
    const newCount = blockedCount + 1;
    
    await chrome.storage.local.set({ blockedCount: newCount });
    chrome.action.setBadgeText({ text: newCount > 999 ? "999+" : String(newCount) });
    chrome.action.setBadgeBackgroundColor({ color: "#4285F4" });
  });
}