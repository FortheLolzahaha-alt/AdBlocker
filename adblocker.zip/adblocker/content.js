// 1. Inject global CSS rules directly into YouTube to instantly hide ad components
const adStyles = document.createElement("style");
adStyles.textContent = `
  ytd-ad-slot-renderer,
  ytd-in-feed-ad-layout-renderer,
  ytd-banner-promo-renderer,
  ytd-statement-banner-renderer,
  #masthead-ad,
  .ytd-merch-shelf-renderer,
  .ytp-ad-overlay-container,
  #player-ads,
  ytd-promoted-sparkles-web-renderer,
  ytd-display-ad-renderer,
  ytd-promoted-video-renderer,
  ytd-compact-promoted-video-renderer,
  yt-mealbar-promo-renderer,
  ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
  ytd-rich-item-renderer:has(.badge-style-type-ad) {
    display: none !important;
  }
`;
(document.head || document.documentElement).appendChild(adStyles);

function purgeYouTubeAds() {
  // 2. Scan home feed & sidebar elements for sponsored badges, text, and aria labels
  document.querySelectorAll("ytd-rich-item-renderer, ytd-compact-video-renderer").forEach((item) => {
    const text = (item.innerText || item.textContent || "").toLowerCase();
    const aria = (item.getAttribute("aria-label") || "").toLowerCase();
    const hasAdBadge = item.querySelector(".badge-style-type-ad, ytd-badge-supported-renderer");

    if (
      text.includes("sponsorlu") || 
      text.includes("sponsored") || 
      aria.includes("sponsorlu") || 
      aria.includes("sponsored") ||
      hasAdBadge
    ) {
      item.style.display = "none";
      item.remove();
    }
  });

  // 3. Force-skip in-video ads and full-screen interstitials
  const player = document.querySelector(".html5-video-player");
  const video = document.querySelector("video");

  if (player && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))) {
    if (video) {
      video.muted = true;
      video.playbackRate = 16;
      if (isFinite(video.duration) && video.duration > 0) {
        video.currentTime = video.duration;
      } else {
        video.currentTime = 9999;
      }
    }

    // Auto-click skip buttons
    const skipSelectors = [
      ".ytp-ad-skip-button",
      ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-slot",
      ".ytp-skip-ad-button",
      ".ytp-ad-skip-button-container button"
    ];

    skipSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((btn) => btn.click());
    });

    // Fallback: Click buttons with "Atla" or "Skip" text
    document.querySelectorAll("button").forEach((btn) => {
      const txt = (btn.innerText || btn.textContent || "").trim().toLowerCase();
      if (txt === "atla" || txt === "skip" || txt.includes("atla") || txt.includes("skip")) {
        btn.click();
      }
    });
  }
}

// Run polling every 50ms for instant execution alongside DOM observer
setInterval(purgeYouTubeAds, 50);

const observer = new MutationObserver(purgeYouTubeAds);
observer.observe(document.body, { childList: true, subtree: true });