function handleYouTubeAds() {
  // 1. Remove feed banners, sidebar ads, and player overlay slots
  const adSelectors = [
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer",
    "#masthead-ad",
    ".ytd-merch-shelf-renderer",
    ".ytp-ad-overlay-container",
    "#player-ads"
  ];

  adSelectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((el) => el.remove());
  });

  // Remove sponsored feed cards
  document.querySelectorAll("ytd-rich-item-renderer").forEach((item) => {
    const text = item.innerText || "";
    if (text.includes("Sponsorlu") || text.includes("Sponsored")) {
      item.remove();
    }
  });

  // 2. Fast-forward & Skip Fullscreen / Interstitial Video Ads
  const player = document.querySelector(".html5-video-player");
  const video = document.querySelector("video");

  if (player && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))) {
    // Mute and jump to the end timestamp of the ad
    if (video) {
      video.muted = true;
      if (isFinite(video.duration) && video.duration > 0) {
        video.currentTime = video.duration;
      } else {
        video.currentTime = 9999;
      }
      video.playbackRate = 16;
    }

    // Auto-click standard skip button selectors
    const skipSelectors = [
      ".ytp-ad-skip-button",
      ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-slot",
      ".ytp-skip-ad-button",
      ".ytp-ad-skip-button-container button"
    ];

    skipSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((btn) => btn.click());
    });

    // Fallback: Click any button explicitly containing "Atla" or "Skip"
    document.querySelectorAll("button").forEach((btn) => {
      const txt = (btn.innerText || btn.textContent || "").trim();
      if (txt === "Atla" || txt === "Skip" || txt.includes("Atla") || txt.includes("Skip")) {
        btn.click();
      }
    });
  }
}

// Execute rapid polling alongside MutationObserver to catch instant overlays
setInterval(handleYouTubeAds, 100);

const observer = new MutationObserver(handleYouTubeAds);
observer.observe(document.body, { childList: true, subtree: true });