(function () {
  // Inject instant CSS to prevent display/feed ads from flickering
  const style = document.createElement("style");
  style.textContent = `
    ytd-ad-slot-renderer,
    ytd-in-feed-ad-layout-renderer,
    ytd-banner-promo-renderer,
    ytd-statement-banner-renderer,
    #masthead-ad,
    .ytd-merch-shelf-renderer,
    .ytp-ad-overlay-container,
    #player-ads,
    ytd-promoted-sparkles-web-renderer,
    ytd-display-ad-renderer,
    ytd-promoted-video-renderer,
    ytd-compact-promoted-video-renderer,
    yt-mealbar-promo-renderer,
    ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
    ytd-rich-item-renderer:has(.badge-style-type-ad),
    ytd-rich-item-renderer:has([aria-label*="Sponsor"]),
    ytd-rich-item-renderer:has([aria-label*="sponsor"]) {
      display: none !important;
    }
  `;
  (document.head || document.documentElement).appendChild(style);

  // Helper to remove ad objects from API responses
  function stripAds(data) {
    if (!data || typeof data !== "object") return data;
    delete data.adPlacements;
    delete data.playerAds;
    delete data.adSlots;
    if (data.playerConfig?.adPlacementConfig) {
      delete data.playerConfig.adPlacementConfig;
    }
    return data;
  }

  // 1. Intercept global initial player response
  let initialResponse = window.ytInitialPlayerResponse;
  Object.defineProperty(window, "ytInitialPlayerResponse", {
    get() {
      return initialResponse;
    },
    set(val) {
      initialResponse = stripAds(val);
    },
    configurable: true
  });

  // 2. Intercept dynamic fetch requests for video player data
  const nativeFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await nativeFetch.apply(this, args);
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url;

    if (url && url.includes("/youtubei/v1/player")) {
      try {
        const clone = response.clone();
        const json = await clone.json();
        const cleanJson = stripAds(json);
        return new Response(JSON.stringify(cleanJson), {
          status: response.status,
          statusText: response.statusText,
          headers: response.headers
        });
      } catch (e) {
        return response;
      }
    }
    return response;
  };
})();