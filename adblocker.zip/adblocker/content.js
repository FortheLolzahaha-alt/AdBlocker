function removeYouTubeAds() {
  // Target standard YouTube ad containers
  const adSelectors = [
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer",
    "#masthead-ad",
    ".ytd-merch-shelf-renderer"
  ];

  adSelectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((el) => el.remove());
  });

  // Catch dynamic feed ads by looking for "Sponsorlu" / "Sponsored" text badges
  const richItems = document.querySelectorAll("ytd-rich-item-renderer");
  richItems.forEach((item) => {
    const text = item.innerText || "";
    if (text.includes("Sponsorlu") || text.includes("Sponsored")) {
      item.remove();
    }
  });
}

// Run immediately
removeYouTubeAds();

// Monitor DOM updates as you scroll
const observer = new MutationObserver(() => {
  removeYouTubeAds();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});