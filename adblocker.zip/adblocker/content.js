function handleYouTubeAds() {
  // 1. Remove feed, sidebar, and banner ad elements
  const adSelectors = [
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer",
    "#masthead-ad",
    ".ytd-merch-shelf-renderer",
    ".ytp-ad-overlay-container"
  ];

  adSelectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((el) => el.remove());
  });

  // Remove sponsored feed cards
  const richItems = document.querySelectorAll("ytd-rich-item-renderer");
  richItems.forEach((item) => {
    const text = item.innerText || "";
    if (text.includes("Sponsorlu") || text.includes("Sponsored")) {
      item.remove();
    }
  });

  // 2. Handle In-Video Ads (Pre-rolls & Mid-rolls)
  const playerContainer = document.querySelector(".html5-video-player");
  const video = document.querySelector("video");

  if (playerContainer && playerContainer.classList.contains("ad-showing")) {
    // Mute and fast-forward unskippable video ads to the end instantly
    if (video && isFinite(video.duration)) {
      video.muted = true;
      video.playbackRate = 16;
      video.currentTime = video.duration;
    }

    // Auto-click "Skip Ad" buttons instantly
    const skipButtons = [
      ".ytp-ad-skip-button",
      ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-slot",
      ".ytp-skip-ad-button"
    ];

    skipButtons.forEach((btnSelector) => {
      const skipBtn = document.querySelector(btnSelector);
      if (skipBtn) {
        skipBtn.click();
      }
    });
  }
}

// Run immediately and observe DOM updates continuously
handleYouTubeAds();

const observer = new MutationObserver(() => {
  handleYouTubeAds();
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});