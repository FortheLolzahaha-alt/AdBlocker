// 1. Inject global CSS rules to instantly hide feed, sidebar, and promo ads
const adStyles = document.createElement("style");
adStyles.textContent = `
  ytd-ad-slot-renderer,
  ytd-in-feed-ad-layout-renderer,
  ytd-banner-promo-renderer,
  ytd-statement-banner-renderer,
  #masthead-ad,
  .ytd-merch-shelf-renderer,
  .ytp-ad-overlay-container,
  #player-ads,
  ytd-promoted-sparkles-web-renderer,
  ytd-display-ad-renderer,
  ytd-promoted-video-renderer,
  ytd-compact-promoted-video-renderer,
  yt-mealbar-promo-renderer,
  ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
  ytd-rich-item-renderer:has(.badge-style-type-ad) {
    display: none !important;
  }
`;
(document.head || document.documentElement).appendChild(adStyles);

let adActive = false;

function handleAds() {
  // Remove feed & sidebar ad cards
  document.querySelectorAll("ytd-rich-item-renderer, ytd-compact-video-renderer").forEach((item) => {
    const text = (item.innerText || item.textContent || "").toLowerCase();
    const aria = (item.getAttribute("aria-label") || "").toLowerCase();
    const hasAdBadge = item.querySelector(".badge-style-type-ad, ytd-badge-supported-renderer");

    if (
      text.includes("sponsorlu") || 
      text.includes("sponsored") || 
      aria.includes("sponsorlu") || 
      aria.includes("sponsored") ||
      hasAdBadge
    ) {
      item.style.display = "none";
      item.remove();
    }
  });

  // Target HTML5 Video Player
  const player = document.querySelector(".html5-video-player");
  const video = document.querySelector("video");

  if (!player || !video) return;

  const isAd = player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting");

  if (isAd) {
    adActive = true;
    video.muted = true;
    video.playbackRate = 16; // Fast forward through ad duration only

    // Click skip buttons instantly ("Atla" / "Skip")
    const skipSelectors = [
      ".ytp-ad-skip-button",
      ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-slot",
      ".ytp-skip-ad-button",
      ".ytp-ad-skip-button-container button"
    ];

    skipSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((btn) => btn.click());
    });

    document.querySelectorAll("button").forEach((btn) => {
      const txt = (btn.innerText || btn.textContent || "").trim().toLowerCase();
      if (txt === "atla" || txt === "skip" || txt.includes("atla") || txt.includes("skip")) {
        btn.click();
      }
    });
  } else if (adActive || video.playbackRate > 2) {
    // Instantly reset speed and unmute for main content
    adActive = false;
    video.playbackRate = 1;
    video.muted = false;
  }
}

// Run checks continuously
setInterval(handleAds, 50);

const observer = new MutationObserver(handleAds);
observer.observe(document.body, { childList: true, subtree: true });